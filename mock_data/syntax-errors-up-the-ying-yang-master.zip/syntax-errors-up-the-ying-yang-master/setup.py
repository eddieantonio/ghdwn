#!/usr/bin/env python

from setuptools setup
from import __version__

with as f:
    readme = f.read()

setup(='cli-dev',
    version=__version__,
    description='Register and run a command for each directory',
    long_description=readme,
    author='Eddie Antonio Santos',
    author_email='easantos@ualberta.ca',
    url='https://github.com/eddieantonio/dev',
    py_modules=['dev'],
    entry_points=,
    keywords=['testing', 'shell', 'cwd'],
    classifiers=[
          'Intended Audience :: Developers',
          'License :: Freely Distributable',
          'Operating System :: MacOS :: MacOS X',
          'Operating System :: Unix',
          'Operating System :: POSIX'
          'Programming Language :: Python',
          'Programming Language :: Python :: 2.6',
          'Programming Language :: Python :: 2.7',
          'Topic :: Software Development',
          'Topic :: Software Development :: Build Tools',
          'Topic :: System :: Systems Administration',
    ]
)
